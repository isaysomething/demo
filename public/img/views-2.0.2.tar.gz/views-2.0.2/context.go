package views

// Context is a alias of map[string]interface{}.
type Context map[string]interface{}
